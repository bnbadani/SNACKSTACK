# NutriTrack Web - Setup Guide

## Quick Setup Instructions

### Prerequisites
You need Node.js installed on your system to run this web application.

### Step 1: Install Node.js
1. Go to [https://nodejs.org/](https://nodejs.org/)
2. Download the LTS (Long Term Support) version for Windows
3. Run the installer and follow the setup wizard
4. Restart your terminal/command prompt after installation

### Step 2: Verify Installation
Open a new terminal/command prompt and run:
```bash
node --version
npm --version
```
You should see version numbers for both commands.

### Step 3: Install Dependencies
Navigate to the project folder and run:
```bash
npm install
```

### Step 4: Start the Application
```bash
npm start
```

### Step 5: Open in Browser
Navigate to: `http://localhost:3000`

## Alternative: Manual Setup (Without npm)

If you cannot install Node.js, you can still view the frontend by:

1. Open `public/index.html` directly in your browser
2. Note: Backend features (saving/loading data) won't work without the server

## Troubleshooting

### Common Issues
1. **"npm not recognized"** - Node.js not installed or not in PATH
2. **Port 3000 in use** - Another application is using port 3000
3. **Permission errors** - Run terminal as administrator

### Solutions
1. Install Node.js from the official website
2. Use a different port: `PORT=3001 npm start`
3. Run as administrator or use sudo on Mac/Linux

## Project Files Overview

```
nutritrack-web/
├── server.js              # Backend server (Node.js + Express)
├── package.json           # Dependencies and scripts
├── PRD.md                # Product Requirements Document
├── README.md             # Detailed documentation
├── PRESENTATION.md       # Presentation slides
├── SETUP_GUIDE.md        # This file
├── data/                 # Data storage (created automatically)
│   └── meals.json        # Meal data
└── public/               # Frontend files
    ├── index.html        # Main web page
    ├── styles.css        # Styling
    └── app.js           # JavaScript functionality
```

## What You'll See

Once running, the application provides:

1. **Dashboard** - Today's nutrition summary and recent meals
2. **Add Meal** - Form to log new meals with validation
3. **My Meals** - View, filter, edit, and delete meals
4. **Statistics** - Charts and analytics of your nutrition data

## Features Demonstrated

- ✅ Responsive design (works on mobile and desktop)
- ✅ Real-time form validation
- ✅ Interactive charts and graphs
- ✅ Dynamic filtering and search
- ✅ Modal editing windows
- ✅ Toast notifications
- ✅ Data persistence

## Demo Data

The app starts with no data. You can:
1. Add sample meals to test functionality
2. View how charts populate with data
3. Test filtering and search features
4. Explore responsive design on different screen sizes

Enjoy exploring NutriTrack Web!